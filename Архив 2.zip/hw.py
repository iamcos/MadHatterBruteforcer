def talk(message):
    return "Talk " + message

def main():
    print( talk("Hello World"))

if __name__ == "__main__":
    main()