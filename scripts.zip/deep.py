from deeppavlov import build_model

model = build_model(, download=True)