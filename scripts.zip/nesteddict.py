indicators = {}

DC = {"length": {"start": 4, "stop": 20, "step": 2}}
indicators["DC"] = DC

print(indicators["DC"]["length"]["start"])
