import unittest
import calc

class TestCalc(unittest.TestCase):
	def test_add(self):
		