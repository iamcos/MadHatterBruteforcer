import numpy as np
import pandas as pd
# bbands = np.r_[bbl, dn, up]
# print(bbands)

# bbands = np.hstack((bbl, dn, up))
# print(bbands)

# bbands = np.vstack((bbl, dn, up))
# print(bbands)

# bbands = np.column_stack((bbl, dn, up))
# print(bbands)

# mk = np.mgrid[0:5,0.0:5]
# print(mk)


# ok = np.ogrid[0:5,0:5]
# print(ok)

# q = np.matrix(np.arange(0,21,2))
# print(q)
# a = np.asmatrix(q)
# print(a)
# z = np.mat(np.arange(0,21,2))
# print(z)
# zz = np.mat([np.arange(0,4,1), np.arange(0,5,1)])
# print(zz)

q = pd.DataFrame({'Bbands' : {'bbl'['up']['dn']:np.arange(0.1,2.3,0.1)}:np.arange(0.1,2.3,0.1)} : np.arange(0,20,1)}})
print(q)
# q = pd.DataFrame({'Bbands' : {'bbl' :{'up': {'dn' : np.arange(0.1,2.3,0.1)}:np.arange(0.1,2.3,0.1)} : np.arange(0,20,1)}})
print(q)