bot = 'bot'
useful = ['rsil','rsib','rsis','bbl','devup','devdn','macdfast','macdslow','macdsign']
useful2 = 'bot.rsi["RsiLength"]','bot.rsi["RsiOversold"]','bot.rsi["RsiOverbought"]','bot.bBands["Length"]','bot.bBands["Devup"]','bot.bBands["Devdn"]','bot.macd["MacdFast"]','bot.macd["MacdSlow"]','bot.macd["MacdSign"]'

# for i, ii  in zip(useful, useful2):
	# print(i+'='+ii)

# print(useful)

# rsil, rsib, rsis, bbl, devup, devdn, macdfast, macdslow, macdsign

bt = [[1]]
bt.append(1)
for i in bt:
	print(bt)