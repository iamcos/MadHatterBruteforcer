	elif indicator =='Aroon Oscillator' and indicator in indicators_bot:
					if fd == 0:
						start = 5
						end = 30
						step = 1
					elif fd == 1:
						start = 5
						end = 30
						step = 1
					elif fd == 2:
						start = 5
						end = 30
						step = 1
					elif fd == 3:
						start = 5
						end = 30
						step = 1
					elif fd == 4:
						start = 5
						end = 30
						step = 1
					elif fd == 5: