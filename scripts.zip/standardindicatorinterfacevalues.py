Short length: 5
 Long length: 34
 Swing: 0
 Minutes before adjust: 180
 Lookback: 30
 Short length: 5
 Long length: 34
 Swing: 0

 RSI Length: 30
 Signal Length: 5
 Buy level: 30
 Sell level: 70
 Buy price: 30
 Buy price: 0
0
 Sell price: 0

 Tenkan-Sen: 9
 Kijun-Sen: 26
 Senkou Span B: 52
 ChikouSpan: 26
 Buy/Sell Trigger: CloudTwist
 Short length: 5
 Long length: 34
 Sma Length: 20
 Multiplier: 2
0
 Atr Length: 10
 Length: 20
 Length: 12
 Buy level: 30
 Sell level: 70
 Short length: 10
 Long length: 26
 Signal length: 9
 Trigger method: MACD-Signal Cross
 ROC: 20
 Buy threshold: 30
 Sell threshold: 70
 ROC: 20
 Buy threshold: -0
2
 Sell threshold: 0
2
 Buy price: 30
 Length: 30
 Buy level: 30
 Sell level: 70
 Acceleration: 0
02
 MaximumStep: 0
2
 Short length: 5
 Long length: 34
 Swing: 0
0
 RSI Length: 30
 Signal Length: 10
 Buy level: 30
 Sell level: 70
 
 Length: 30
 Buy level: 30
 Sell level: 70
 RSI Length: 30
 Fast K: 5
 Fast D: 4
 Buy level: 30
 Sell level: 70
 Trigger method: Threshold Cross
 Length: 30
 Buy level: 30
 Sell level: 70
 Minutes before signal change: 10
 Number Of Candles For Buy: 9
 Lookback For Buy: 4
 Signal When Buy Sequence Broke: False
 Number Of Candles For Sell: 9
 Lookback For Sell: 4
 Signal When Sell Sequence Broke: False
 Short length: 5
 Long length: 34
 Length: 20
 Short length: 5
 Long length: 34
 Swing: 0
0
 Short Length: 7
 Middle Length: 14
 Long Length: 28
 Short length: 5
 Long length: 34
 Swing: 0
0
 Length: 30
 Buy level: -30
 Sell level: -70
 Lookback: 25
 Lookback: 25
 Length: 20
 Buy threshold: -0
5
 Sell threshold: 0
5
 
 Length: 20
 Dev.Up: 2
 Dev.Down: 2
 Length: 20
 Dev.Up: 2
0
 Dev.Down: 2
0
 Length: 20
 Dev.Up: 2
0
 Dev.Down: 2
0
 Buy level: 0
001
 Sell level: 0
002
 Length: 20
 Dev.Down: 2
0
 Dev.Up: 2
0
 Pattern: None
 Length: 20
 Buy threshold: -10
0
 Sell threshold: 10
0
 Length: 3
 U/D Length: 2
 ROC: 100
 Buy level: 10
 Sell level: 90
 ROC-1: 11
 ROC-2: 14
 WMALength: 14
 Buy threshold: -0
1
 Sell threshold: 0
1
 Length: 20
 Length-1: 5
 Length-2: 34
 Buy threshold: -2
 Sell threshold: 2
 Short: 12
 Long: 24
 Buy threshold: -0
1
 Sell threshold: 0
1
 Length: 20
 Buy threshold: -50
0
 Sell threshold: 50
0])