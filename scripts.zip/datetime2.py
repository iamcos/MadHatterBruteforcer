import time
from datetime import date

today = date.today()

print("today is", today)
