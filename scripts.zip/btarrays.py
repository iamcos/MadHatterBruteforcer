directory = './binance'
ori_name = ['ADA\BNB 8900.csv','ADA\BTC 5500.csv','ADA\BTC 8900.csv','ARK\ETH 5600.csv','BAT\ETH 5600.csv','BNB\USDT 3400.csv','BTC\USDT 3400.csv','BTG\BTC 3400.csv','DOGE\BNB 5600.csv','DOGE\BTC 5600.csv','DOGE\USDT 5600.csv','ENJ\ETH 5600.csv','EOS\BNB 5600.csv','ERD\BNB 5600.csv','ERD\USDT 5600.csv','ETH\BTC 3400.csv','ETH\TUSD 3400.csv','ETH\USDC 5600.csv','ETH\USDT 3400.csv','FET\BTC 5600.csv','FTM\TUSD 5600.csv','GVT\BTC 5600.csv','HC\BTC 5600.csv']
stocks = [directory + s for s in ori_name]
stocks