def settherange():
    therange = int(
        input(
            "Write the N% of backtests to be done at each operation. The recomended values are 3, 6, 12, 20"
        )
    )
    return int(therange)
