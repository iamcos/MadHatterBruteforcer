import telegram

bot = telegram.Bot(token="952803998:AAEBqnO0C7zrHv6oQB3lormOGFAjnLBiwk4")
print(bot.get_me())
# {"first_name": "Toledo's Palace Bot", "username": "ToledosPalaceBot"}
