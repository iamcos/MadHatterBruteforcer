import pandas as pd

dt = "2019-08-01 02:16:00"

date = pd.to_datetime(dt)
print(date)
